import urllib.request
import subprocess
import sys
import os

def clr():
    os.system("cls" if os.name == "nt" else "clear")

def updt():
    url = "https://raw.githubusercontent.com/phtuankiet/dowcode/refs/heads/main/enjuly-bot.py"
    filename = "cailonmemay.py"
    
    try:
        print("Đang Tải Update...")
        code = urllib.request.urlopen(url).read().decode("utf-8")
        
        with open(filename, "w", encoding="utf-8") as f:
            f.write(code)
        
        print("Đã Tải Xong, Đang Chạy Tool...")
        
        clr()
        
        result = subprocess.run([sys.executable, filename], 
                              capture_output=False,
                              text=True)
        
        print(f"Tool Đã Chạy Xong Với Exit Code: {result.returncode}")
        
    except Exception as e:
        print(f"Lỗi: {e}")
    
    finally:
        if os.path.exists(filename):
            try:
                os.remove(filename)
                print("Đã Xóa File Tạm")
            except:
                pass

def updtrun():
    url = "https://raw.githubusercontent.com/phtuankiet/dowcode/refs/heads/main/enjuly-bot.py"
    filename = "cailonmemay.py"
    
    try:
        print("Đang Tải Update...")
        code = urllib.request.urlopen(url).read().decode("utf-8")
        
        with open(filename, "w", encoding="utf-8") as f:
            f.write(code)
        
        print("Đang Khởi Chạy Tool...")
        
        clr()
        
        process = subprocess.Popen([sys.executable, filename],
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)
        
        print(f"Tool Đã Được Khởi Động Với PID: {process.pid}")
        return process
        
    except Exception as e:
        print(f"Lỗi: {e}")
        return None

if __name__ == "__main__":
    updt()
    
    #hoặc chạy ngầm
    #rocess = updtrun()
    #if process:
    #    print("chạy nền tool...")